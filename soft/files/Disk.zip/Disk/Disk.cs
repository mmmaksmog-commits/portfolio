﻿// Диск by mysik — карта занятого места: что занимает диск, большие файлы, типы файлов.

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;
using Mysik;
using IOPath = System.IO.Path;
using WF = System.Windows.Forms;

[assembly: AssemblyTitle("Диск")]
[assembly: AssemblyDescription("Диск by mysik — карта занятого места на диске")]
[assembly: AssemblyCompany("mysik")]
[assembly: AssemblyProduct("Диск by mysik")]
[assembly: AssemblyCopyright("by mysik")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]

namespace Disk
{
    static class Program
    {
        [STAThread]
        static void Main() { Boot.Run("Диск", "DiskByMysik_SingleInstance", () => new MainWindow()); }
    }

    // ------------------------------------------------------------------ данные

    class Node
    {
        public string Name, Path;
        public Node Parent;
        public bool IsDir, IsRest;
        public long Size, Files;
        public List<Node> Kids = new List<Node>();
        public long[] Cat = new long[Cats.Count];
    }

    static class Cats
    {
        public const int Count = 7;
        public static readonly string[] Names = { "Видео", "Фото", "Музыка", "Игры и программы", "Архивы и образы", "Документы", "Другое" };
        public static readonly Color[] Colors =
        {
            Color.FromRgb(232, 96, 126), Color.FromRgb(242, 179, 61), Color.FromRgb(167, 139, 250), Color.FromRgb(47, 179, 110),
            Color.FromRgb(96, 165, 250), Color.FromRgb(148, 163, 184), Color.FromRgb(90, 97, 112)
        };
        static readonly Dictionary<string, int> Map = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);

        static Cats()
        {
            Add(0, ".mp4 .mkv .avi .mov .wmv .webm .m4v .flv .ts .mts .m2ts .3gp .mpg .mpeg .vob");
            Add(1, ".jpg .jpeg .png .gif .bmp .webp .heic .heif .tif .tiff .raw .cr2 .nef .arw .dng .psd .svg .ico");
            Add(2, ".mp3 .flac .wav .aac .m4a .ogg .opus .wma .aiff .alac");
            Add(3, ".exe .dll .sys .msi .pak .bin .dat .vpk .uasset .ucas .utoc .bundle .assets .forge .cab .sav .bnk .wem");
            Add(4, ".zip .rar .7z .tar .gz .xz .bz2 .iso .img .vhd .vhdx .wim .esd");
            Add(5, ".pdf .doc .docx .xls .xlsx .ppt .pptx .txt .rtf .odt .csv .djvu .epub .fb2");
        }

        static void Add(int cat, string exts) { foreach (var e in exts.Split(' ')) Map[e] = cat; }

        public static int Of(string name)
        {
            int c;
            return Map.TryGetValue(IOPath.GetExtension(name), out c) ? c : 6;
        }

        public static Color Dominant(Node n)
        {
            if (!n.IsDir) return Colors[Of(n.Name)];
            int best = 6;
            long max = -1;
            for (int i = 0; i < Count; i++) if (n.Cat[i] > max) { max = n.Cat[i]; best = i; }
            return Colors[best];
        }
    }

    // ------------------------------------------------------------------ быстрое сканирование (FindFirstFileEx)

    class Scanner
    {
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        struct WIN32_FIND_DATAW
        {
            public uint dwFileAttributes;
            public System.Runtime.InteropServices.ComTypes.FILETIME ftCreationTime, ftLastAccessTime, ftLastWriteTime;
            public uint nFileSizeHigh, nFileSizeLow, dwReserved0, dwReserved1;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 260)] public string cFileName;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 14)] public string cAlternateFileName;
        }

        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        static extern IntPtr FindFirstFileExW(string name, int infoLevel, out WIN32_FIND_DATAW data, int searchOp, IntPtr filter, int flags);
        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        static extern bool FindNextFileW(IntPtr h, out WIN32_FIND_DATAW data);
        [DllImport("kernel32.dll")]
        static extern bool FindClose(IntPtr h);

        const uint DIR = 0x10, REPARSE = 0x400;
        const int KeepFiles = 40;
        static readonly IntPtr Invalid = new IntPtr(-1);

        public long FilesSeen, BytesSeen;
        public string Current = "";
        public volatile bool Cancel;
        public int Denied;
        readonly object bigLock = new object();
        public readonly List<Node> BigFiles = new List<Node>();

        public Node Scan(string root)
        {
            var node = new Node { Name = root, Path = root, IsDir = true };
            // корень: верхние папки сканируем параллельно
            var dirs = ListDir(node);
            Parallel.ForEach(dirs, new ParallelOptions { MaxDegreeOfParallelism = Math.Max(2, Environment.ProcessorCount) }, d => Walk(d));
            Finish(node);
            return node;
        }

        // Читает одну папку: создаёт узлы папок, крупные файлы, остальные складывает в «Другие файлы».
        List<Node> ListDir(Node dir)
        {
            var subdirs = new List<Node>();
            var files = new List<Node>();
            string pattern = (dir.Path.StartsWith(@"\\") ? dir.Path : @"\\?\" + dir.Path).TrimEnd('\\') + @"\*";
            WIN32_FIND_DATAW fd;
            IntPtr h = FindFirstFileExW(pattern, 1, out fd, 0, IntPtr.Zero, 2);
            if (h == Invalid) { Interlocked.Increment(ref Denied); return subdirs; }
            try
            {
                do
                {
                    string n = fd.cFileName;
                    if (n == "." || n == "..") continue;
                    if ((fd.dwFileAttributes & DIR) != 0)
                    {
                        if ((fd.dwFileAttributes & REPARSE) != 0) continue; // ссылки на другие папки не считаем дважды
                        var d = new Node { Name = n, Path = IOPath.Combine(dir.Path, n), Parent = dir, IsDir = true };
                        subdirs.Add(d);
                    }
                    else
                    {
                        long size = ((long)fd.nFileSizeHigh << 32) | fd.nFileSizeLow;
                        var f = new Node { Name = n, Parent = dir, Size = size, Files = 1 };
                        files.Add(f);
                        Interlocked.Increment(ref FilesSeen);
                        Interlocked.Add(ref BytesSeen, size);
                    }
                } while (!Cancel && FindNextFileW(h, out fd));
            }
            finally { FindClose(h); }

            files.Sort((a, b) => b.Size.CompareTo(a.Size));
            var rest = new Node { Name = "", Parent = dir, IsRest = true };
            for (int i = 0; i < files.Count; i++)
            {
                var f = files[i];
                dir.Cat[Cats.Of(f.Name)] += f.Size;
                if (f.Size >= 50L * 1024 * 1024)
                {
                    f.Path = IOPath.Combine(dir.Path, f.Name);
                    lock (bigLock) BigFiles.Add(f);
                }
                if (i < KeepFiles) dir.Kids.Add(f);
                else { rest.Size += f.Size; rest.Files++; }
            }
            if (rest.Files > 0)
            {
                rest.Name = "Другие файлы (" + rest.Files + ")";
                dir.Kids.Add(rest);
            }
            dir.Kids.AddRange(subdirs);
            Current = dir.Path;
            return subdirs;
        }

        void Walk(Node dir)
        {
            if (Cancel) return;
            foreach (var d in ListDir(dir)) Walk(d);
            Finish(dir);
        }

        // Итоги папки: размер, число файлов, типы — из детей.
        static void Finish(Node dir)
        {
            long size = 0, files = 0;
            foreach (var k in dir.Kids)
            {
                if (k.IsDir)
                {
                    for (int i = 0; i < Cats.Count; i++) dir.Cat[i] += k.Cat[i];
                    files += k.Files;
                }
                else files += k.Files;
                size += k.Size;
            }
            dir.Size = size;
            dir.Files = files;
            dir.Kids.Sort((a, b) => b.Size.CompareTo(a.Size));
        }
    }

    // ------------------------------------------------------------------ карта (squarified treemap)

    static class Treemap
    {
        public static List<KeyValuePair<Node, Rect>> Layout(List<Node> items, Rect area)
        {
            var res = new List<KeyValuePair<Node, Rect>>();
            var list = items.Where(n => n.Size > 0).ToList();
            double total = list.Sum(n => (double)n.Size);
            if (total <= 0 || area.Width < 2 || area.Height < 2) return res;
            double k = area.Width * area.Height / total;
            var queue = new Queue<Node>(list);
            var r = area;
            var row = new List<Node>();
            while (queue.Count > 0)
            {
                var next = queue.Peek();
                double side = Math.Min(r.Width, r.Height);
                if (row.Count == 0 || Worst(row, null, side, k) >= Worst(row, next, side, k))
                {
                    row.Add(queue.Dequeue());
                    continue;
                }
                r = Place(row, r, k, res);
                row.Clear();
            }
            if (row.Count > 0) Place(row, r, k, res);
            return res;
        }

        static double Worst(List<Node> row, Node extra, double side, double k)
        {
            double sum = 0, max = 0, min = double.MaxValue;
            foreach (var n in row) { double a = n.Size * k; sum += a; max = Math.Max(max, a); min = Math.Min(min, a); }
            if (extra != null) { double a = extra.Size * k; sum += a; max = Math.Max(max, a); min = Math.Min(min, a); }
            if (sum <= 0 || min <= 0) return double.MaxValue;
            double s2 = sum * sum, w2 = side * side;
            return Math.Max(w2 * max / s2, s2 / (w2 * min));
        }

        static Rect Place(List<Node> row, Rect r, double k, List<KeyValuePair<Node, Rect>> res)
        {
            double sum = row.Sum(n => n.Size * k);
            if (r.Width >= r.Height)
            {
                double w = Math.Min(r.Width, sum / r.Height);
                double y = r.Y;
                foreach (var n in row)
                {
                    double h = n.Size * k / w;
                    res.Add(new KeyValuePair<Node, Rect>(n, new Rect(r.X, y, w, h)));
                    y += h;
                }
                return new Rect(r.X + w, r.Y, Math.Max(0, r.Width - w), r.Height);
            }
            else
            {
                double h = Math.Min(r.Height, sum / r.Width);
                double x = r.X;
                foreach (var n in row)
                {
                    double w = n.Size * k / h;
                    res.Add(new KeyValuePair<Node, Rect>(n, new Rect(x, r.Y, w, h)));
                    x += w;
                }
                return new Rect(r.X, r.Y + h, r.Width, Math.Max(0, r.Height - h));
            }
        }
    }

    static class Recycle
    {
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        struct SHFILEOPSTRUCT
        {
            public IntPtr hwnd;
            public uint wFunc;
            public string pFrom, pTo;
            public ushort fFlags;
            public bool fAnyOperationsAborted;
            public IntPtr hNameMappings;
            public string lpszProgressTitle;
        }

        [DllImport("shell32.dll", CharSet = CharSet.Unicode)]
        static extern int SHFileOperation(ref SHFILEOPSTRUCT op);

        public static bool Delete(string path)
        {
            var op = new SHFILEOPSTRUCT { wFunc = 3, pFrom = path + "\0\0", fFlags = 0x40 | 0x10 | 0x4 | 0x400 };
            return SHFileOperation(ref op) == 0 && !op.fAnyOperationsAborted && !File.Exists(path) && !Directory.Exists(path);
        }
    }

    // ------------------------------------------------------------------ окно

    class MainWindow : ShellWindow
    {
        WrapPanel drivePanel, crumbs, legend;
        Button folderBtn, upBtn;
        RadioButton tabFolders, tabFiles, tabTypes;
        StackPanel listPanel, placeholder;
        Canvas map;
        TextBlock placeholderTitle, placeholderText;
        Grid scanBarHost;
        Border scanBar;
        System.Windows.Documents.Run statusRun;

        Node root, current;
        Scanner scanner;
        long usedOnDrive;
        int tab;
        DispatcherTimer progress;
        Stopwatch sw;

        public MainWindow()
        {
            LoadUi("Диск by mysik", 1080, 740);
            ResizeMode = ResizeMode.CanResizeWithGrip;
            MinWidth = 900;
            MinHeight = 560;

            drivePanel = F<WrapPanel>("DrivePanel");
            crumbs = F<WrapPanel>("Crumbs");
            legend = F<WrapPanel>("Legend");
            folderBtn = F<Button>("FolderBtn");
            upBtn = F<Button>("UpBtn");
            tabFolders = F<RadioButton>("TabFolders");
            tabFiles = F<RadioButton>("TabFiles");
            tabTypes = F<RadioButton>("TabTypes");
            listPanel = F<StackPanel>("ListPanel");
            placeholder = F<StackPanel>("Placeholder");
            map = F<Canvas>("Map");
            placeholderTitle = F<TextBlock>("PlaceholderTitle");
            placeholderText = F<TextBlock>("PlaceholderText");
            scanBarHost = F<Grid>("ScanBarHost");
            scanBar = F<Border>("ScanBar");
            statusRun = F<System.Windows.Documents.Run>("StatusRun");

            folderBtn.Click += (s, e) =>
            {
                using (var d = new WF.FolderBrowserDialog { Description = "Какую папку проверить?", ShowNewFolderButton = false })
                    if (d.ShowDialog() == WF.DialogResult.OK) Start(d.SelectedPath, 0);
            };
            upBtn.Click += (s, e) => { if (current != null && current.Parent != null) Go(current.Parent); };
            tabFolders.Checked += (s, e) => { tab = 0; RenderList(); };
            tabFiles.Checked += (s, e) => { tab = 1; RenderList(); };
            tabTypes.Checked += (s, e) => { tab = 2; RenderList(); };
            map.SizeChanged += (s, e) => RenderMap();
            MouseDown += (s, e) => { if (e.ChangedButton == MouseButton.XButton1 && current != null && current.Parent != null) Go(current.Parent); };

            for (int i = 0; i < Cats.Count; i++)
            {
                var sp = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 0, 14, 0) };
                sp.Children.Add(new Border { Width = 10, Height = 10, CornerRadius = new CornerRadius(3), Background = Br(Cats.Colors[i]), Margin = new Thickness(0, 0, 6, 0), VerticalAlignment = VerticalAlignment.Center });
                sp.Children.Add(Txt(Cats.Names[i], 12, CSub, false));
                legend.Children.Add(sp);
            }
        }

        public override void Init()
        {
            var pill = S("Pill");
            foreach (var d in DriveInfo.GetDrives())
            {
                try
                {
                    if (!d.IsReady || (d.DriveType != DriveType.Fixed && d.DriveType != DriveType.Removable)) continue;
                    var drive = d;
                    long used = d.TotalSize - d.TotalFreeSpace;
                    var sp = new StackPanel { MinWidth = 120 };
                    string label = d.Name.TrimEnd('\\') + "  " + (string.IsNullOrEmpty(d.VolumeLabel) ? "Локальный диск" : d.VolumeLabel);
                    sp.Children.Add(new TextBlock { Text = label, FontWeight = FontWeights.SemiBold, FontSize = 13 });
                    var bar = new Grid { Height = 4, Margin = new Thickness(0, 5, 0, 4) };
                    bar.Children.Add(new Border { Background = Br(CLine), CornerRadius = new CornerRadius(2) });
                    double frac = d.TotalSize > 0 ? (double)used / d.TotalSize : 0;
                    bar.Children.Add(new Border
                    {
                        Background = Br(frac > 0.9 ? CRed : frac > 0.75 ? CAmber : CGreen), CornerRadius = new CornerRadius(2),
                        HorizontalAlignment = HorizontalAlignment.Left, Width = 120 * frac
                    });
                    sp.Children.Add(bar);
                    sp.Children.Add(new TextBlock { Text = "свободно " + FmtBytes(d.TotalFreeSpace) + " из " + FmtBytes(d.TotalSize), FontSize = 11, Foreground = Br(CSub) });
                    var rb = new RadioButton { Style = pill, Content = sp, GroupName = "drive" };
                    rb.Checked += (s, e) => Start(drive.RootDirectory.FullName, used);
                    drivePanel.Children.Add(rb);
                }
                catch { }
            }
        }

        // -------------------------------------------------- сканирование

        async void Start(string path, long used)
        {
            if (scanner != null) scanner.Cancel = true;
            var sc = new Scanner();
            scanner = sc;
            usedOnDrive = used;
            root = current = null;
            listPanel.Children.Clear();
            crumbs.Children.Clear();
            map.Children.Clear();
            placeholder.Visibility = Visibility.Visible;
            placeholderTitle.Text = "Сканирую " + path;
            placeholderText.Text = "Считаю файлы…";
            scanBarHost.Visibility = Visibility.Visible;
            scanBar.Width = 0;
            sw = Stopwatch.StartNew();

            if (progress == null)
            {
                progress = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(200) };
                progress.Tick += (s, e) => ShowProgress();
            }
            progress.Start();

            Node result = null;
            try { result = await Task.Run(() => sc.Scan(path)); }
            catch (Exception ex) { placeholderText.Text = "Ошибка: " + ex.Message; }
            if (sc != scanner || sc.Cancel) return;
            progress.Stop();
            scanBarHost.Visibility = Visibility.Collapsed;
            if (result == null) return;

            root = result;
            placeholder.Visibility = Visibility.Collapsed;
            statusRun.Text = path + " · " + FmtBytes(root.Size) + " · " + Plural((int)Math.Min(int.MaxValue, root.Files), "файл", "файла", "файлов") +
                             " · " + (int)sw.Elapsed.TotalSeconds + " с" + (sc.Denied > 0 ? " · закрытых папок: " + sc.Denied : "");
            Go(root);
            if (sc.Denied > 20)
                Toast("Часть системных папок закрыта. Для полной картины запусти программу от имени администратора");
        }

        void ShowProgress()
        {
            var sc = scanner;
            if (sc == null) return;
            long b = Interlocked.Read(ref sc.BytesSeen);
            placeholderText.Text = FmtBytes(b) + " · " + Plural((int)Math.Min(int.MaxValue, Interlocked.Read(ref sc.FilesSeen)), "файл", "файла", "файлов") +
                                   "\n" + Shorten(sc.Current, 60);
            if (usedOnDrive > 0) scanBar.Width = 300 * Math.Min(1, (double)b / usedOnDrive);
        }

        static string Shorten(string s, int n)
        {
            s = s ?? "";
            return s.Length <= n ? s : "…" + s.Substring(s.Length - n);
        }

        // -------------------------------------------------- навигация и отрисовка

        void Go(Node n)
        {
            current = n;
            upBtn.IsEnabled = n.Parent != null;
            RenderCrumbs();
            RenderList();
            RenderMap();
        }

        void RenderCrumbs()
        {
            crumbs.Children.Clear();
            var chain = new List<Node>();
            for (var n = current; n != null; n = n.Parent) chain.Insert(0, n);
            if (chain.Count > 4) chain = new[] { chain[0] }.Concat(chain.Skip(chain.Count - 3)).ToList();
            for (int i = 0; i < chain.Count; i++)
            {
                var n = chain[i];
                if (i > 0) crumbs.Children.Add(new TextBlock { Text = i == 1 && chain[1].Parent != chain[0] ? " › … › " : " › ", Foreground = Br(CFaint), VerticalAlignment = VerticalAlignment.Center });
                var t = new TextBlock
                {
                    Text = n.Parent == null ? n.Name.TrimEnd('\\') : n.Name, Foreground = Br(i == chain.Count - 1 ? CText : CGreen),
                    FontWeight = i == chain.Count - 1 ? FontWeights.SemiBold : FontWeights.Normal, Cursor = Cursors.Hand, VerticalAlignment = VerticalAlignment.Center,
                    MaxWidth = 140, TextTrimming = TextTrimming.CharacterEllipsis
                };
                t.MouseLeftButtonUp += (s, e) => Go(n);
                crumbs.Children.Add(t);
            }
        }

        void RenderList()
        {
            listPanel.Children.Clear();
            if (root == null) return;
            if (tab == 0)
            {
                foreach (var k in current.Kids.Take(200))
                    listPanel.Children.Add(Row(k, current.Size, k.IsDir || k.IsRest ? null : Cats.Names[Cats.Of(k.Name)]));
            }
            else if (tab == 1)
            {
                var files = scanner.BigFiles.Where(f => f.Path.StartsWith(current.Path, StringComparison.OrdinalIgnoreCase))
                                            .OrderByDescending(f => f.Size).Take(150).ToList();
                if (files.Count == 0)
                    listPanel.Children.Add(new TextBlock { Text = "Файлов больше 50 МБ здесь нет", Foreground = Br(CSub), Margin = new Thickness(10, 14, 10, 14) });
                long top = files.Count > 0 ? files[0].Size : 1;
                foreach (var f in files) listPanel.Children.Add(Row(f, top, f.Parent.Path));
            }
            else
            {
                long total = Math.Max(1, current.Cat.Sum());
                foreach (int i in Enumerable.Range(0, Cats.Count).OrderByDescending(j => current.Cat[j]))
                {
                    if (current.Cat[i] == 0) continue;
                    var g = new StackPanel { Margin = new Thickness(10, 10, 10, 6) };
                    var head = Columns(Auto, Star, Auto);
                    head.Children.Add(new Border { Width = 12, Height = 12, CornerRadius = new CornerRadius(3), Background = Br(Cats.Colors[i]), Margin = new Thickness(0, 0, 10, 0), VerticalAlignment = VerticalAlignment.Center });
                    head.Children.Add(At(Txt(Cats.Names[i], 13.5, CText, true), 1));
                    head.Children.Add(At(Txt(FmtBytes(current.Cat[i]) + "  ·  " + Math.Round(current.Cat[i] * 100.0 / total) + "%", 12.5, CSub, false), 2));
                    g.Children.Add(head);
                    g.Children.Add(Bar(current.Cat[i] / (double)total, Cats.Colors[i]));
                    listPanel.Children.Add(g);
                }
                listPanel.Children.Add(new TextBlock { Text = "Типы считаются по расширению файлов.", Style = (Style)Root.FindResource("Hint"), Margin = new Thickness(10, 10, 10, 6) });
            }
        }

        UIElement Bar(double frac, Color c)
        {
            var bar = new Grid { Height = 4, Margin = new Thickness(0, 6, 0, 0) };
            bar.Children.Add(new Border { Background = Br(CLine), CornerRadius = new CornerRadius(2) });
            var fill = new Border { Background = Br(c), CornerRadius = new CornerRadius(2), HorizontalAlignment = HorizontalAlignment.Left };
            bar.Children.Add(fill);
            bar.SizeChanged += (s, e) => fill.Width = Math.Max(2, bar.ActualWidth * Math.Max(0, Math.Min(1, frac)));
            return bar;
        }

        UIElement Row(Node n, long of, string sub)
        {
            var color = Cats.Dominant(n);
            var g = new StackPanel { Margin = new Thickness(8, 7, 8, 7) };
            var head = Columns(Auto, Star, Auto);
            var icon = new Border { Width = 26, Height = 26, CornerRadius = new CornerRadius(7), Background = Br(Color.FromArgb(50, color.R, color.G, color.B)), Margin = new Thickness(0, 0, 10, 0) };
            icon.Child = new TextBlock
            {
                Text = n.IsDir ? "\uE8B7" : n.IsRest ? "\uE8B9" : "\uE7C3", FontFamily = Icons, FontSize = 12, Foreground = Br(color),
                HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center
            };
            head.Children.Add(icon);
            var name = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
            name.Children.Add(Txt(n.Name, 13, CText, n.IsDir));
            if (sub != null) name.Children.Add(Txt(sub, 11, CFaint, false));
            else if (n.IsDir) name.Children.Add(Txt(Plural((int)Math.Min(int.MaxValue, n.Files), "файл", "файла", "файлов"), 11, CFaint, false));
            head.Children.Add(At(name, 1));
            head.Children.Add(At(Txt(FmtBytes(n.Size), 13, CText, true), 2));
            g.Children.Add(head);
            g.Children.Add(Bar(of > 0 ? (double)n.Size / of : 0, color));

            var host = new Border { Background = Brushes.Transparent, CornerRadius = new CornerRadius(10), Child = g, Cursor = n.IsDir ? Cursors.Hand : Cursors.Arrow };
            host.MouseEnter += (s, e) => host.Background = Br(CCard2);
            host.MouseLeave += (s, e) => host.Background = Brushes.Transparent;
            host.MouseLeftButtonUp += (s, e) => { if (n.IsDir) Go(n); else if (n.Path != null) Reveal(n.Path); };
            if (!n.IsRest) host.ContextMenu = Menu(n);
            host.ToolTip = n.IsRest ? "Мелкие файлы этой папки вместе" : (n.Path ?? IOPath.Combine(n.Parent.Path, n.Name));
            return host;
        }

        ContextMenu Menu(Node n)
        {
            var m = new ContextMenu();
            var open = new MenuItem { Header = n.IsDir ? "Открыть в проводнике" : "Показать в проводнике" };
            open.Click += (s, e) => Reveal(PathOf(n));
            var del = new MenuItem { Header = "Удалить в корзину…" };
            del.Click += async (s, e) => await DeleteNode(n);
            m.Items.Add(open);
            m.Items.Add(del);
            return m;
        }

        static string PathOf(Node n) { return n.Path ?? IOPath.Combine(n.Parent.Path, n.Name); }

        static void Reveal(string path)
        {
            try
            {
                if (Directory.Exists(path)) Process.Start("explorer.exe", "\"" + path + "\"");
                else Process.Start("explorer.exe", "/select,\"" + path + "\"");
            }
            catch { }
        }

        async Task DeleteNode(Node n)
        {
            string path = PathOf(n);
            bool yes = await Ask("Удалить в корзину?", path + "\n\n" + FmtBytes(n.Size) + (n.IsDir ? " · " + Plural((int)Math.Min(int.MaxValue, n.Files), "файл", "файла", "файлов") : "") +
                                 "\n\nЕсли это файлы программы или игры, лучше удали её через «Параметры → Приложения».", "Удалить", "Отмена");
            if (!yes) return;
            bool ok = await Task.Run(() => Recycle.Delete(path));
            if (!ok) { Toast("Не получилось удалить: файл занят или нет доступа"); return; }
            // убираем из дерева и пересчитываем размеры вверх
            var p = n.Parent;
            p.Kids.Remove(n);
            scanner.BigFiles.RemoveAll(f => f == n || PathOf(f).StartsWith(path + "\\", StringComparison.OrdinalIgnoreCase));
            for (var a = p; a != null; a = a.Parent)
            {
                a.Size -= n.Size;
                a.Files -= n.Files;
                if (n.IsDir) for (int i = 0; i < Cats.Count; i++) a.Cat[i] -= n.Cat[i];
                else a.Cat[Cats.Of(n.Name)] -= n.Size;
                a.Kids.Sort((x, y) => y.Size.CompareTo(x.Size));
            }
            Toast("В корзине. Освобождено " + FmtBytes(n.Size) + " (после очистки корзины)");
            Go(current == n ? p : current);
        }

        void RenderMap()
        {
            map.Children.Clear();
            if (current == null || map.ActualWidth < 10) return;
            var items = current.Kids.Where(k => k.Size > 0).Take(120).ToList();
            var rects = Treemap.Layout(items, new Rect(0, 0, map.ActualWidth, map.ActualHeight));
            foreach (var kv in rects)
            {
                var n = kv.Key;
                var r = kv.Value;
                if (r.Width < 1 || r.Height < 1) continue;
                var c = Cats.Dominant(n);
                double shade = n.IsDir ? 1 : 0.8;
                var fill = new LinearGradientBrush(
                    Color.FromArgb(255, (byte)(c.R * shade), (byte)(c.G * shade), (byte)(c.B * shade)),
                    Color.FromArgb(255, (byte)(c.R * shade * 0.72), (byte)(c.G * shade * 0.72), (byte)(c.B * shade * 0.72)), 45);
                var b = new Border
                {
                    Width = Math.Max(0, r.Width - 2), Height = Math.Max(0, r.Height - 2), Background = fill,
                    CornerRadius = new CornerRadius(Math.Min(6, Math.Min(r.Width, r.Height) / 4)), Cursor = n.IsDir ? Cursors.Hand : Cursors.Arrow,
                    ToolTip = n.Name + "\n" + FmtBytes(n.Size) + (n.IsDir ? " · " + Plural((int)Math.Min(int.MaxValue, n.Files), "файл", "файла", "файлов") : "")
                };
                if (r.Width > 70 && r.Height > 34)
                {
                    var sp = new StackPanel { Margin = new Thickness(8, 6, 8, 6) };
                    sp.Children.Add(new TextBlock { Text = n.Name, Foreground = Brushes.White, FontWeight = FontWeights.SemiBold, FontSize = r.Width > 180 && r.Height > 70 ? 14 : 12, TextTrimming = TextTrimming.CharacterEllipsis });
                    if (r.Height > 50) sp.Children.Add(new TextBlock { Text = FmtBytes(n.Size), Foreground = new SolidColorBrush(Color.FromArgb(210, 255, 255, 255)), FontSize = 11.5 });
                    b.Child = sp;
                }
                b.MouseEnter += (s, e) => b.Opacity = 0.85;
                b.MouseLeave += (s, e) => b.Opacity = 1;
                b.MouseLeftButtonUp += (s, e) => { if (n.IsDir) Go(n); };
                if (!n.IsRest) b.ContextMenu = Menu(n);
                Canvas.SetLeft(b, r.X + 1);
                Canvas.SetTop(b, r.Y + 1);
                map.Children.Add(b);
            }
        }
    }
}
